//
//  Detail.h
//  Music
//
//  Created by Dianna Mertz on 11/5/12.
//  Copyright (c) 2012 Dianna Mertz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface Detail : UITableViewController
{
    NSString *playlistTitle;
}

@property NSString *playlistTitle;

@end
